Sprites Extracted by: Schubert

My Github: https://github.com/schuberty

Extraction Software: AssetStudio v0.15.23

Uploaded to: https://www.spriters-resource.com/pc_computer/amongus

If you would like to have the PSD files, contact me on the vg resource website: https://www.vg-resource.com/user-75424.html

Advertising: Sprites of some tasks might be in another task folder, to avoid duplicated ones. (ex: upload/download button used on "Upload Data" and "Process Data" task; garbage leaves sprites will be on "Clean O2 Filter" task)

Thanks for the download and ENJOY!